<?php
namespace Common;

class Teszt{
	
	function __construct(){
		echo("helllloooooo");
	}
		
}





?>
