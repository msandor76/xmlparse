<?php

return array(

	// Buttons
	'open_subpage' => 'Aloldal nyitása',
	'back_home' => 'Kezdőoldalra',

);
