<?php

return array(

	// Index method
	'welcome_text' => 'Isten hozott!',
	'welcome_message' => '
		Üdvözöllek ez egy teszt szöveg...
	',


);
