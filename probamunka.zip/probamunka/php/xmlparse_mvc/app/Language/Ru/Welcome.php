<?php
/**
 * Sample language
 */
return array(

	// Index method
	'welcomeText' => 'Добро пожаловать!',
	'welcomeMessage' => '
		Здраствуй, добро пожаловать в привствующий контролер! <br/>
		Содержимое этого файла может быть изменено в <code>app/views/welcome/welcome.php</code>
	',

	// Subpage method
	'subpageText' => 'Подстраница',
	'subpageMessage' => '
		Здраствуй, добро пожаловать в привствующий контролер в метод подстраницы! <br/>
		Содержимое этого файла можеть быть изменено в <code>app/views/welcome/subpage.php</code>
	',

	// Buttons
	'openSubpage' => 'Открыть подстраницу',
	'backHome' => 'Домой',

);
