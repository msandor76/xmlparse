<?php 
namespace App\Models;

use Core\Model;

class WelcomeModel extends Model 
{    
    function __construct(){
        parent::__construct();
        //echo("teeeeeszt");
    }  
}
