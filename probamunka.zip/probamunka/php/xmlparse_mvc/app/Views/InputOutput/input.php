<?php
use Core\Language;
?>



<div class="row">
	
	<div class="col-sm-12">
		<!-- fő  -->
					
		<h3>Importálás kész</h3>
		
		<a class="btn btn-md btn-success" href="<?php echo SITEURL; ?>termekek">Termékek listája</a>
		
		<!-- END fő -->
	</div>
	
</div><!-- row END -->
