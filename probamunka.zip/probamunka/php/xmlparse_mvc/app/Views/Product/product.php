<?php
use Core\Language;
?>



<div class="row">
	
	<div class="col-sm-12">
		<!-- fő  -->
					
		<h3>Termék adatlap</h3>
		
		
		
		<a class="btn btn-md btn-success" href="<?php echo SITEURL; ?>termekek">vissza a kezdőoldalra</a>
		
		<!-- END fő -->
	</div>

</div><!-- row END -->
