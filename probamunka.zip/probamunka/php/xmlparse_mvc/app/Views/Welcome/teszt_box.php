ez egy teszt box
<hr>
<?php
echo $data["txttobox"];
?>
