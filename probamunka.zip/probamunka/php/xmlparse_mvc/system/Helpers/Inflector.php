<?php
/**
 * Inflector Helper
 *
 * @author Virgil-Adrian Teaca - virgil@giulianaeassociati.com
 * @version 1.0
 */

namespace Helpers;

class Inflector extends \Doctrine\Common\Inflector\Inflector
{
}
